var nome = prompt("Digite seu primeiro nome:")
var sobrenome = prompt("Digite seu sobrenome:")
alert("Olá, " + nome + " " + sobrenome + "!")
