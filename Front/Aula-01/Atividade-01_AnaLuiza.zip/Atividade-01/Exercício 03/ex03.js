var numero = Number(prompt("Digite um número:"))
var cubo = numero ** 3
alert("O cubo do seu número é " + cubo)
