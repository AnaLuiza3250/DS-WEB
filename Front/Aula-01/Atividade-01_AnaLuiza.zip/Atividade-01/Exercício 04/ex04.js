var cel = Number(prompt("Digite a temperatura que deseja converter:"))
var fa = (cel - 32) * 0.5556
alert(cel + "° Fahrenheit equivalem a " + fa + "° Celsius")
