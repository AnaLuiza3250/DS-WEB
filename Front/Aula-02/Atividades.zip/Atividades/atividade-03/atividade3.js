document.getElementById("caixa").style.width = "1920px";
document.getElementById("caixa").style.height = "1080px";


function azul() {
    document.getElementById("caixa").style.backgroundColor = "#003554";
    document.getElementById("caixa").style.color = "#00A6FB";
    document.getElementById("caixa").innerHTML = "<h1>Bem-vindo ao mundo dos Smurffs</h1>";
}

function verde() {
    document.getElementById("caixa").style.backgroundColor = "#1B3E2D";
    document.getElementById("caixa").style.color = "#81BEA1";
    document.getElementById("caixa").innerHTML = "<h1>Bem-vindo ao mundo do Grinch</h1>";
}

function vermelho() {
    document.getElementById("caixa").style.backgroundColor = "#ec2229";
    document.getElementById("caixa").style.color = "#efb3b5";
    document.getElementById("caixa").innerHTML = "<h1>Bem-vindo ao mundo da Chapeuzinho Vermelho</h1>";
}